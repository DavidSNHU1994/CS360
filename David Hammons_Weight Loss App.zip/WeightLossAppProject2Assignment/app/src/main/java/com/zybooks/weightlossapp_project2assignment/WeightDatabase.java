package com.zybooks.weightlossapp_project2assignment;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class WeightDatabase extends SQLiteOpenHelper {

    //Create database name
    private static final String DB_NAME = "Weight Tracking";

    //Create database version
    private static final int DB_VERSION = 1;

    //Create name for our table
    private static final String TABLE_NAME = "Weight Table";

    //Create name for weight column
    private static final String WEIGHT_COL = "Daily Weight";

    //Create name for date column
    private static final String DATE_COL = "Date";

    //Create name for deviance column
    private static final String DEVIANCE_COL = "Deviance";

    //Constructor for the database handler
    public WeightDatabase(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    //create database by running SQLite query
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //Creating our table and the data types they will take
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + WEIGHT_COL + " TEXT,"
                + DATE_COL + " TEXT,"
                + DEVIANCE_COL + " TEXT)";

        //execute the above SQL query
        sqLiteDatabase.execSQL(query);
    }

    //adds new entry into our SQLite database
    public void addNewDailyWeight(String weight, String date, String deviance){

        //creating a variable for our database and calling a writable method
        SQLiteDatabase db = this.getWritableDatabase();

        //variable for content values
        ContentValues values = new ContentValues();

        //passing all values with it's key and value pair
        values.put(WEIGHT_COL, weight);
        values.put(DATE_COL, date);
        values.put(DEVIANCE_COL, deviance);

        //passing content values into the table
        db.insert(TABLE_NAME, null, values);

        //closing our database after adding values
        db.close();

    }

    //Checks to see if the table already exists
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }
}
