package com.zybooks.weightlossapp_project2assignment;


public class LoginUsers {
    private int userID;
    private String username;
    private String password;

    //Constructor for creating a user object upon initialization
    public LoginUsers(int userID, String username, String password){
        this.userID = userID;
        this.username = username;
        this.password = password;
    }

    //Gets userID
    public int getUserID(){
        return userID;
    }

    //gets username
    public String getUsername(){
        return username;
    }

    //gets password
    public String getPassword(){
        return password;
    }
}
