package com.zybooks.weightlossapp_project2assignment;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    //declare variables as well as initialize LoginUsers
    //Default user is username admin and password admin
    LoginUsers user = new LoginUsers(1, "admin", "admin");
    private WeightDatabase db;
    Button weightInputButton;
    Button loginButton;
    Button weightButton;
    EditText username;
    EditText password;
    EditText dailyWeight;
    Date c = Calendar.getInstance().getTime();
    String formattedString;
    String deviance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        //initialize variables
        loginButton = (Button)findViewById(R.id.loginButton);
        username = (EditText)findViewById(R.id.usernameText);
        password = (EditText)findViewById(R.id.passwordText);

        SimpleDateFormat df = new SimpleDateFormat("MMM-dd-yyyy", Locale.getDefault());
        formattedString = df.format(c);


        //Action for when login button is clicked
        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                //Checks username and password - if correct it lets you in
                if(username.getText().toString().equals(user.getUsername()) && password.getText().toString().equals(user.getPassword())){
                    setContentView(R.layout.activity_main);
                    weightInputButton = (Button)findViewById(R.id.weightInputButton);

                    //Takes you to activity weight input screen upon pressing button
                    weightInputButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            setContentView(R.layout.activity_weight_input);

                            weightButton = (Button)findViewById(R.id.weightButton);
                            dailyWeight = (EditText)findViewById(R.id.addWeightNumber);

                            weightButton.setOnClickListener(new View.OnClickListener() {

                                final String weight = dailyWeight.getText().toString();
                                @Override
                                public void onClick(View view) {
                                    if(weight.isEmpty()){
                                        Toast.makeText(MainActivity.this, "Please input a weight", Toast.LENGTH_SHORT).show();
                                    }
                                    else {

                                        deviance = String.valueOf(Integer.parseInt(weight) - 185);
                                        db.addNewDailyWeight(weight, formattedString, deviance);

                                    }
                                }
                            });
                        }
                    });
                } else {
                    Toast.makeText(MainActivity.this, "The username or password is incorrect", Toast.LENGTH_SHORT).show();
                }
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}